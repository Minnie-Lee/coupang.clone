import React from 'react';
import { Search, ShoppingCart, User, Menu, ChevronRight, Star, Zap, ChevronLeft, HelpCircle } from 'lucide-react';

export default function ShoppingMallHome() {
  const getImg = (name: string) => {
    const base = import.meta.env.BASE_URL.endsWith("/") ? import.meta.env.BASE_URL : `${import.meta.env.BASE_URL}/`;
    return `${base}images/shopping-mall/${name}`;
  };

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 pb-20">
      {/* Top Banner (Ad) */}
      <div className="bg-blue-600 text-white text-center py-2 text-sm font-medium tracking-tight">
        첫 구매 고객에게는 1만원 쿠폰팩 100% 지급! <span className="underline cursor-pointer ml-2">지금 확인하기</span>
      </div>

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-[1200px] mx-auto px-4">
          {/* Top small links */}
          <div className="flex justify-end gap-4 py-1 text-xs text-gray-500">
            <a href="#" className="hover:text-gray-800">로그인</a>
            <a href="#" className="hover:text-gray-800">회원가입</a>
            <a href="#" className="hover:text-gray-800">고객센터</a>
          </div>

          {/* Main Header area */}
          <div className="flex items-center py-4 gap-8">
            <div className="flex-shrink-0 cursor-pointer">
              <span className="text-3xl font-extrabold text-[#E11A38] tracking-tighter">MEGA<span className="text-black">MALL</span></span>
            </div>

            {/* Search */}
            <div className="flex-grow max-w-2xl">
              <div className="relative flex items-center w-full h-12 rounded-full border-2 border-[#E11A38] bg-white overflow-hidden focus-within:ring-2 focus-within:ring-[#E11A38]/20 transition-all">
                <input 
                  type="text" 
                  placeholder="찾고 싶은 상품을 검색해보세요!" 
                  className="w-full h-full px-5 outline-none text-base placeholder-gray-400"
                />
                <button className="h-full px-5 text-[#E11A38] hover:bg-gray-50 transition-colors">
                  <Search size={24} />
                </button>
              </div>
              <div className="flex gap-3 mt-2 text-xs text-gray-500">
                <span className="font-semibold text-gray-700">인기검색어</span>
                <a href="#" className="hover:text-[#E11A38]">마스크</a>
                <a href="#" className="hover:text-[#E11A38]">생수 2L</a>
                <a href="#" className="hover:text-[#E11A38]">아이폰15</a>
                <a href="#" className="hover:text-[#E11A38]">닭가슴살</a>
                <a href="#" className="hover:text-[#E11A38]">무선청소기</a>
              </div>
            </div>

            {/* Icons */}
            <div className="flex items-center gap-6 ml-auto text-gray-700">
              <button className="flex flex-col items-center gap-1 hover:text-[#E11A38] transition-colors">
                <User size={28} strokeWidth={1.5} />
                <span className="text-xs">마이페이지</span>
              </button>
              <button className="flex flex-col items-center gap-1 hover:text-[#E11A38] transition-colors relative">
                <div className="relative">
                  <ShoppingCart size={28} strokeWidth={1.5} />
                  <span className="absolute -top-1 -right-2 bg-[#E11A38] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white">
                    3
                  </span>
                </div>
                <span className="text-xs">장바구니</span>
              </button>
            </div>
          </div>
        </div>

        {/* Categories Nav */}
        <div className="border-t border-gray-100">
          <div className="max-w-[1200px] mx-auto px-4 flex items-center h-12">
            <button className="flex items-center gap-2 text-gray-800 font-bold pr-6 border-r border-gray-200 h-full hover:text-[#E11A38]">
              <Menu size={20} />
              카테고리
            </button>
            <nav className="flex gap-8 pl-6 text-[15px] font-medium text-gray-800">
              <a href="#" className="text-[#E11A38] font-bold">베스트</a>
              <a href="#" className="hover:text-[#E11A38]">신상특가</a>
              <a href="#" className="hover:text-[#E11A38]">기획전</a>
              <a href="#" className="hover:text-[#E11A38]">패션/뷰티</a>
              <a href="#" className="hover:text-[#E11A38]">식품</a>
              <a href="#" className="hover:text-[#E11A38]">가전/디지털</a>
              <a href="#" className="hover:text-[#E11A38]">생활용품</a>
              <a href="#" className="hover:text-[#E11A38]">여행/티켓</a>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto px-4 pt-6 flex flex-col gap-10">
        
        {/* Banner Area */}
        <section className="relative w-full h-[380px] rounded-2xl overflow-hidden group cursor-pointer shadow-sm">
          <img 
            src={getImg("banner-1.jpg")}
            alt="MEGA SALE" 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex flex-col justify-center px-16 text-white">
            <h2 className="text-5xl font-black mb-4 tracking-tight drop-shadow-md">MEGA SALE<br/>최대 80% 할인</h2>
            <p className="text-lg font-medium opacity-90 drop-shadow-md">이번 주말 한정 기특한 가격으로 만나보세요</p>
          </div>
          <button className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white hover:text-black transition-colors opacity-0 group-hover:opacity-100">
            <ChevronLeft size={24} />
          </button>
          <button className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center text-white hover:bg-white hover:text-black transition-colors opacity-0 group-hover:opacity-100">
            <ChevronRight size={24} />
          </button>
          <div className="absolute bottom-4 right-8 bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full text-xs text-white">
            1 / 5
          </div>
        </section>

        {/* Quick Menus */}
        <section className="grid grid-cols-8 gap-4 py-4 border-b border-gray-200">
          {[
            { name: "타임특가", bg: "bg-red-50", text: "text-red-600" },
            { name: "번개배송", bg: "bg-blue-50", text: "text-blue-600" },
            { name: "신선식품", bg: "bg-green-50", text: "text-green-600" },
            { name: "패션의류", bg: "bg-pink-50", text: "text-pink-600" },
            { name: "가전제품", bg: "bg-gray-100", text: "text-gray-700" },
            { name: "생활용품", bg: "bg-yellow-50", text: "text-yellow-600" },
            { name: "뷰티", bg: "bg-purple-50", text: "text-purple-600" },
            { name: "전체보기", bg: "bg-gray-100", text: "text-gray-800" },
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center gap-2 cursor-pointer group">
              <div className={`w-16 h-16 rounded-full ${item.bg} flex items-center justify-center transition-transform group-hover:-translate-y-1`}>
                <span className={`font-bold ${item.text}`}>{item.name[0]}</span>
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-black">{item.name}</span>
            </div>
          ))}
        </section>

        {/* Fast Delivery Section */}
        <section>
          <div className="flex items-end justify-between mb-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Zap size={24} className="text-[#0084FF] fill-[#0084FF]" />
                <h3 className="text-2xl font-extrabold tracking-tight">번개배송</h3>
              </div>
              <p className="text-sm text-gray-500 font-medium">밤 12시 전 주문 시 내일 아침 도착!</p>
            </div>
            <a href="#" className="text-sm font-medium text-gray-500 hover:text-gray-900 flex items-center">
              전체보기 <ChevronRight size={16} />
            </a>
          </div>

          <div className="grid grid-cols-5 gap-4">
            <ProductCard 
              image={getImg("product-earphones.jpg")}
              title="노이즈 캔슬링 무선 블루투스 이어폰 화이트 프로 3세대"
              price={189000}
              originalPrice={250000}
              discount={24}
              rating={4.8}
              reviews={1423}
              isFast={true}
            />
            <ProductCard 
              image={getImg("product-strawberries.jpg")}
              title="[산지직송] 논산 당도선별 설향 딸기 500g 2팩"
              price={15900}
              originalPrice={22000}
              discount={27}
              rating={4.6}
              reviews={3852}
              isFast={true}
            />
            <ProductCard 
              image={getImg("product-tissue.jpg")}
              title="프리미엄 천연펄프 3겹 화장지 30m 30롤 2팩"
              price={24500}
              originalPrice={35000}
              discount={30}
              rating={4.9}
              reviews={12504}
              isFast={true}
            />
            <ProductCard 
              image={getImg("product-sparkling.jpg")}
              title="플레인 탄산수 500ml 20페트 무라벨"
              price={12900}
              originalPrice={18000}
              discount={28}
              rating={4.7}
              reviews={8432}
              isFast={true}
            />
            <ProductCard 
              image={getImg("product-porkbelly.jpg")}
              title="[1등급] 국내산 한돈 생 삼겹살 구이용 1kg"
              price={21900}
              originalPrice={29000}
              discount={24}
              rating={4.8}
              reviews={5621}
              isFast={true}
            />
          </div>
        </section>

        {/* Banner Break */}
        <section className="w-full h-24 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl overflow-hidden relative flex items-center justify-between px-10 cursor-pointer shadow-sm group">
          <div className="text-white z-10">
            <h4 className="text-xl font-bold mb-1">디지털 가전 빅세일 페스타</h4>
            <p className="text-sm opacity-80 font-medium">노트북부터 TV까지 최대 50만원 카드 할인 혜택</p>
          </div>
          <div className="z-10 bg-white text-indigo-700 px-5 py-2 rounded-full font-bold text-sm shadow-md group-hover:scale-105 transition-transform">
            할인받기
          </div>
          {/* Decorative shapes */}
          <div className="absolute right-32 top-0 w-32 h-32 bg-white opacity-10 rounded-full blur-2xl"></div>
          <div className="absolute left-1/2 bottom-0 w-48 h-48 bg-black opacity-10 rounded-full blur-3xl"></div>
        </section>

        {/* Hot Deals */}
        <section>
          <div className="mb-5">
            <h3 className="text-2xl font-extrabold tracking-tight text-[#E11A38]">놓치면 후회하는 타임특가</h3>
            <div className="flex items-center gap-2 mt-2">
              <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded">03</span>
              <span className="font-bold text-lg">:</span>
              <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded">45</span>
              <span className="font-bold text-lg">:</span>
              <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded">22</span>
              <span className="text-sm text-gray-500 ml-2 font-medium">남음</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-6">
            <ProductCard 
              image={getImg("product-monitor.jpg")}
              title="32인치 QHD 144Hz 게이밍 모니터 1ms 응답속도"
              price={299000}
              originalPrice={450000}
              discount={33}
              rating={4.8}
              reviews={920}
              isFast={false}
              tag="특가"
            />
            <ProductCard 
              image={getImg("product-cardigan.jpg")}
              title="여성용 데일리 브이넥 루즈핏 니트 가디건 베이지"
              price={19900}
              originalPrice={45000}
              discount={55}
              rating={4.5}
              reviews={210}
              isFast={true}
              tag="특가"
            />
            <ProductCard 
              image={getImg("product-vacuum.jpg")}
              title="스마트 로봇청소기 물걸레 듀얼 매핑 시스템 화이트"
              price={459000}
              originalPrice={700000}
              discount={34}
              rating={4.9}
              reviews={342}
              isFast={true}
              tag="특가"
            />
            <ProductCard 
              image={getImg("product-vitamin.jpg")}
              title="고함량 비타민C 1000mg 300정 10개월분 면역력"
              price={14900}
              originalPrice={30000}
              discount={50}
              rating={4.8}
              reviews={15340}
              isFast={true}
              tag="특가"
            />
          </div>
        </section>
        
        {/* Recommended Grids (2 columns) */}
        <div className="grid grid-cols-2 gap-8 mb-10">
          <div className="bg-white p-6 rounded-2xl border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-bold text-lg">인기 급상승 뷰티 랭킹</h4>
              <span className="text-xs text-gray-400">10:00 기준</span>
            </div>
            <div className="flex flex-col gap-4">
              {[1, 2, 3].map((rank) => (
                <div key={rank} className="flex gap-4 items-center group cursor-pointer">
                  <div className="relative w-16 h-16 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                    <div className="absolute top-0 left-0 bg-black text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-br-md z-10">
                      {rank}
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <p className="text-sm font-medium line-clamp-1 group-hover:underline text-gray-800">
                      진정 보습 히알루론산 수분 크림 대용량 100ml
                    </p>
                    <div className="flex gap-1 items-baseline mt-1">
                      <span className="text-xs font-bold text-[#E11A38]">45%</span>
                      <span className="font-bold">14,900원</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-2xl border border-gray-200">
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-bold text-lg">지금 뜨는 패션 트렌드</h4>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-100 h-32 rounded-lg relative overflow-hidden group cursor-pointer">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <span className="absolute bottom-2 left-2 text-white font-bold text-sm drop-shadow-md">#봄신상 가디건</span>
              </div>
              <div className="bg-gray-100 h-32 rounded-lg relative overflow-hidden group cursor-pointer">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <span className="absolute bottom-2 left-2 text-white font-bold text-sm drop-shadow-md">#편안한 셋업</span>
              </div>
              <div className="bg-gray-100 h-32 rounded-lg relative overflow-hidden group cursor-pointer">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <span className="absolute bottom-2 left-2 text-white font-bold text-sm drop-shadow-md">#와이드 팬츠</span>
              </div>
              <div className="bg-gray-100 h-32 rounded-lg relative overflow-hidden group cursor-pointer">
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                <span className="absolute bottom-2 left-2 text-white font-bold text-sm drop-shadow-md">#포인트 스니커즈</span>
              </div>
            </div>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white mt-10 pt-10 pb-16">
        <div className="max-w-[1200px] mx-auto px-4">
          <div className="grid grid-cols-4 gap-8 mb-8 border-b border-gray-100 pb-8">
            <div className="col-span-1">
              <h5 className="font-bold text-lg mb-4">고객센터</h5>
              <p className="text-3xl font-extrabold text-[#E11A38] mb-2">1588-0000</p>
              <p className="text-sm text-gray-500 mb-1">운영시간 09:00 - 18:00 (주말/공휴일 휴무)</p>
              <div className="flex gap-2 mt-4">
                <button className="border border-gray-300 rounded px-3 py-1.5 text-xs font-medium hover:bg-gray-50">1:1 문의하기</button>
                <button className="border border-gray-300 rounded px-3 py-1.5 text-xs font-medium hover:bg-gray-50">자주묻는질문</button>
              </div>
            </div>
            
            <div className="col-span-3 flex justify-between text-sm text-gray-600">
              <div>
                <h6 className="font-bold text-gray-800 mb-3">MEGA MALL</h6>
                <ul className="flex flex-col gap-2">
                  <li><a href="#" className="hover:underline">회사소개</a></li>
                  <li><a href="#" className="hover:underline">인재채용</a></li>
                  <li><a href="#" className="hover:underline">입점/제휴 문의</a></li>
                </ul>
              </div>
              <div>
                <h6 className="font-bold text-gray-800 mb-3">서비스안내</h6>
                <ul className="flex flex-col gap-2">
                  <li><a href="#" className="hover:underline">번개배송 안내</a></li>
                  <li><a href="#" className="hover:underline">멤버십 혜택</a></li>
                  <li><a href="#" className="hover:underline">쿠폰/포인트</a></li>
                </ul>
              </div>
              <div>
                <h6 className="font-bold text-gray-800 mb-3">정책 및 약관</h6>
                <ul className="flex flex-col gap-2">
                  <li><a href="#" className="hover:underline font-bold text-gray-800">개인정보처리방침</a></li>
                  <li><a href="#" className="hover:underline">이용약관</a></li>
                  <li><a href="#" className="hover:underline">청소년보호정책</a></li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="text-xs text-gray-400 space-y-2">
            <p className="font-medium text-gray-500">주식회사 메가몰</p>
            <p>대표이사: 홍길동 | 사업자등록번호: 123-45-67890 | 통신판매업신고: 2023-서울강남-0000</p>
            <p>주소: 서울특별시 강남구 테헤란로 123 메가타워 | 개인정보보호책임자: 김철수</p>
            <p className="mt-4">메가몰은 통신판매중개자이며, 통신판매의 당사자가 아닙니다. 상품, 상품정보, 거래에 관한 의무와 책임은 판매자에게 있습니다.</p>
            <p className="pt-2">Copyright © MEGAMALL Corp. All Rights Reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

// Subcomponents

function ProductCard({ 
  image, 
  title, 
  price, 
  originalPrice, 
  discount, 
  rating, 
  reviews, 
  isFast,
  tag
}: { 
  image: string, 
  title: string, 
  price: number, 
  originalPrice: number, 
  discount: number, 
  rating: number, 
  reviews: number,
  isFast: boolean,
  tag?: string
}) {
  return (
    <div className="group cursor-pointer flex flex-col">
      <div className="relative aspect-square rounded-xl overflow-hidden mb-3 bg-gray-100">
        <img 
          src={image} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {tag && (
          <div className="absolute top-2 left-2 bg-[#E11A38] text-white text-xs font-bold px-2 py-1 rounded shadow-sm">
            {tag}
          </div>
        )}
      </div>
      
      <div className="flex flex-col flex-grow">
        <div className="text-[13px] text-gray-500 mb-1 line-clamp-1">{title.split(' ')[0]} {title.split(' ')[1]}</div>
        <h4 className="text-[15px] leading-snug mb-2 line-clamp-2 text-gray-800 font-medium group-hover:text-[#E11A38] transition-colors">
          {title}
        </h4>
        
        <div className="mt-auto">
          {originalPrice && (
            <div className="text-gray-400 text-sm line-through decoration-gray-300">
              {originalPrice.toLocaleString()}원
            </div>
          )}
          <div className="flex items-baseline gap-1.5 mb-2">
            {discount > 0 && (
              <span className="text-lg font-bold text-[#E11A38]">{discount}%</span>
            )}
            <span className="text-lg font-extrabold">{price.toLocaleString()}</span>
            <span className="text-sm font-medium">원</span>
          </div>
          
          <div className="flex items-center justify-between">
            {isFast ? (
              <div className="flex items-center gap-0.5 text-[#0084FF] text-xs font-bold bg-[#0084FF]/10 px-1.5 py-0.5 rounded">
                <Zap size={10} className="fill-[#0084FF]" />
                번개배송
              </div>
            ) : (
              <div className="text-xs text-gray-500">일반배송</div>
            )}
            
            <div className="flex items-center gap-0.5 text-xs text-gray-500">
              <Star size={12} className="text-yellow-400 fill-yellow-400" />
              <span className="font-medium text-gray-700">{rating}</span>
              <span className="text-gray-400">({reviews.toLocaleString()})</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
